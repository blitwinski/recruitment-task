<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PetController extends Controller
{

    public function create(Request $request)
    {
        $request->validate(['name' => 'required|min:3|max:20']);

        $response = Http::post('https://petstore.swagger.io/v2/pet/',
        [
            'name' => $request->input('name')

          ]);

        $pets = $response->json();
          dump($pets);
        return view('pets.index', ['pets' => $pets]);
    }

    public function index()
    {
       // $pets_array = [5,10,22,37];
       // $random_id = array_rand($pets_array,1);
       // dump($random_id);
        $response = Http::get('https://petstore.swagger.io/v2/pet/5');
        $pets = $response->json();
      //  dump($pets);
      //  dump(gettype($pets));

        return view('pets.index', ['pets' => $pets]);
        //return view('pets.index',compact('pets'));
    }

    public function edit($id)
    {
        $response = Http::get('https://petstore.swagger.io/v2/pet/' . $id);
        $pets = $response->json();

        return view('pets.edit', ['pets' => $pets]);
    }

    public function update(Request $request, $id)
    {
         $response = Http::put('https://petstore.swagger.io/v2/pet/', [
            'id' => $id,
            'name' => $request->input('name'),
            //'body' => $request->input('body'),
        ]);
        //dd($response->json());
        //$response->update($request->all());
        //$response->json();

        //$response->update($request);
        $pets = $response->json();
        if ($response->successful()) {
            return redirect()->route('pets.index')->with('success', 'Updated successfully')
            ->with(['pets' => $pets]);
            } else {
           return redirect()->route('pets.index')->with('error', 'Update failed');
           }
        //return view('pets.index', ['pets' => $pets]);
    }

    public function destroy($id)
    {
        $response = Http::delete('https://petstore.swagger.io/v2/pet/' . $id);

        if ($response->successful()) {
            return redirect()->route('pets.index')->with('success', 'Entry deleted');
        } else {
            return redirect()->route('pets.index')->with('error', 'Delete failed');
        }
    }
}
