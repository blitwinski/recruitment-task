<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Edit</h1>
        <form action="<?php echo e(route('pets.update', $pets['id'])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($pets['name']); ?>">
            </div>
            <div class="mb-3">
                <label for="body" class="form-label">Body</label>
                <textarea class="form-control" id="body" name="body"><?php echo e('no body'); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/blitwinski/b894a916-6b96-419d-aaad-b8430514d7bc3/blitwinski/Desktop/recruitment-task/pets/resources/views/pets/edit.blade.php ENDPATH**/ ?>