<form action="<?php echo e(route('pets.create')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Enter name</label>
            <input type="text" class="form-control" id="name" name="name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <button type="submit" class="btn btn-primary">Add New</button>
    </div>
</form>
<?php /**PATH /media/blitwinski/b894a916-6b96-419d-aaad-b8430514d7bc3/blitwinski/Desktop/recruitment-task/pets/resources/views/pets/create.blade.php ENDPATH**/ ?>