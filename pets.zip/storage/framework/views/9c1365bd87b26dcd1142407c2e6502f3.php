<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Pets</h1>
        <div class="table-responsive mt-3">
            <table class="table table-striped">
                <?php echo $__env->make('pets.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($pets['id'] ?? ""); ?></td>
                        <td><?php echo e($pets['name'] ?? ""); ?></td>
                        <td>
                            <div class="d-flex">
                                <a href="<?php echo e(route('pets.edit', $pets['id'])); ?>" class="btn btn-sm btn-primary me-2">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('pets.destroy', $pets['id'])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/blitwinski/b894a916-6b96-419d-aaad-b8430514d7bc3/blitwinski/Desktop/recruitment-task/pets/resources/views/pets/index.blade.php ENDPATH**/ ?>